<?php $page="about";?>
<!DOCTYPE html>
<html>
    <head>
        <title>Nucleus Compass</title>
        <link rel="stylesheet" href="/bootstrap.css"/>
        <script src="/jquery-1.11.2.min.js"></script>
        <script src="/bootstrap.js"></script>
    </head>
    <body>
<?php require("nav.php");  ?>
              
        
        
</body>
</html>